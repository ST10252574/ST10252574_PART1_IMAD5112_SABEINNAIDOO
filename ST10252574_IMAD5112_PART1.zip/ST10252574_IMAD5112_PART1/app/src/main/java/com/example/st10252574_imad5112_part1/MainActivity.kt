package com.example.st10252574_imad5112_part1

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        btn_Fuctions()

    }

    //FUNCTION NAME ALONG WITH MY DECLARED VARIABLES

        fun btn_Fuctions(){
            var number1 = findViewById<EditText>(R.id.number1)
            var number2 = findViewById<EditText>(R.id.number2)
            var addBtn = findViewById<Button>(R.id.addBtn)
            var subBtn = findViewById<Button>(R.id.subtractBtn)
            var mulBtn = findViewById<Button>(R.id.mulBtn)
            var divBtn = findViewById<Button>(R.id.divBtn)
            var resetBtn = findViewById<Button>(R.id.resetBtn)
            var display = findViewById<TextView>(R.id.display)


            //ADDITION BUTTON FUNCTIONALITY
            addBtn.setOnClickListener {
                var sum1 = number1.text.toString().toInt()
                var sum2 = number2.text.toString().toInt()
                //VAR ADDING ALONG WITH + ADDS THE 2 NUMBERS
                var adding = sum1 + sum2
                //DISPLAYS ANSWER IN THE TEXTVIEW
                display.text = adding.toString()


            }

            //SUBTRACTION BUTTON FUNCTIONALITY
            subBtn.setOnClickListener {
                var sum1 = number1.text.toString().toInt()
                var sum2 = number2.text.toString().toInt()
                //VAR MINUS ALONG WITH - SUBTRACTS THE 2 NUMBERS
                var minus = sum1 - sum2
                //DISPLAYS ANSWER IN THE TEXTVIEW
                display.text = minus.toString()


            }
            //MULTIPLICATION BUTTON FUNCTIONALITY
            mulBtn.setOnClickListener {
                var sum1 = number1.text.toString().toInt()
                var sum2 = number2.text.toString().toInt()
                //VAR MUL ALONG WITH * MULTIPLIES THE 2 NUMBERS
                var mul = sum1 * sum2
                //DISPLAYS ANSWER IN THE TEXTVIEW
                display.text = mul.toString()


            }

            //DIVISION BUTTON FUNCTIONALITY
            divBtn.setOnClickListener {
                var sum1 = number1.text.toString().toInt()
                var sum2 = number2.text.toString().toInt()
                //VAR DIVIDING ALONG WITH / DIVIDES THE 2 NUMBERS
                var dividing = sum1 / sum2
                //DISPLAYS ANSWER IN THE TEXTVIEW
                display.text = dividing.toString()


            }

            //RESET BUTTON FUNCTIONALITY
            resetBtn.setOnClickListener {

                number1.setText("")
                number2.setText("")
                display.text = ("")
                //ADDED TOAST MESSAGE TO INFORM USER THAT THE RESET BUTTON IS FULLY FUNCTIONAL
                Toast.makeText(this,"Successfully Reset", Toast.LENGTH_LONG).show()
            }


        }

}
// REFERENCES USED:
// 2 YOUTUBE VIDEOS BASED ON BASIC CALCULATOR FUNCTIONS USING KOTLIN IN ANDROID STUDIO
//BELOW ARE THE LINKS TO THOSE SPECIFIED VIDEOS
// LINK 1: https://www.youtube.com/watch?v=v24Bhk7wQI8&t=950s
// LINK 2: https://www.youtube.com/watch?v=Zi1XgFTUH9k&t=1316s
//THANK YOU!!, PLEASE ENJOY MY APP!


